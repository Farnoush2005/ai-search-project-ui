from collections import deque

def bfs(start_state):
    # صف و مجموعه استیت‌های ویزیت‌شده رو با نقطه شروع مقداردهی می‌کنیم
    queue = deque([(start_state, [])])
    visited = {start_state}
    
    while queue:
        curr_state, path = queue.popleft()
        
        # اگه رسیدیم به هدف، مسیر رو برگردون
        if curr_state.is_goal_state():
            return path
            
        # بررسی حرکت‌های مجاز بعدی
        for action, step_cost, next_state in curr_state.get_successors(toward_walls=True):
            
            # بی‌خیال مسیرهایی که به دیوار ختم میشن
            if next_state.is_collision_state():
                continue
            
            # اگه این استیت جدیده، به صف اضافه میشه تا بعداً چکش کنیم
            if next_state not in visited:
                visited.add(next_state)
                queue.append((next_state, path + [action]))
                    
    return []  # اگه هیچ مسیری پیدا نشد