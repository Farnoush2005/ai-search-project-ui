import heapq
import itertools

def astar(start_state):
    # تابع هیوریستیک برای تخمین هزینه باقی‌مانده تا هدف
    def get_h(state):
        targets = list(state.get_targets_positions())
        if not targets:
            return 0
        
        pos = state.get_agent_position()
        w_pos = state.get_weapon_position()
        has_w = state.has_weapon()
        
        # فاصله منهتن تا نزدیک‌ترین هدف
        dist_to_t = min(abs(pos[0] - t[0]) + abs(pos[1] - t[1]) for t in targets)
        
        # محاسبه MST اگه چندتا هدف داشتیم
        mst = 0
        if len(targets) > 1:
            edges = []
            for i in range(len(targets)):
                for j in range(i + 1, len(targets)):
                    d = abs(targets[i][0] - targets[j][0]) + abs(targets[i][1] - targets[j][1])
                    edges.append((d, i, j))
            edges.sort()
            
            # پیاده‌سازی کروسکال برای درخت پوشای کمینه
            parent = list(range(len(targets)))
            def find(i):
                if parent[i] == i:
                    return i
                parent[i] = find(parent[i])  # path compression
                return parent[i]
                
            for d, u, v in edges:
                r1, r2 = find(u), find(v)
                if r1 != r2:
                    parent[r1] = r2
                    mst += d
        
        # هزینه تخمینی بدون در نظر گرفتن سلاح
        c_no_w = (dist_to_t + mst) * 5
        
        # اگه اسلحه هست ولی نداریمش، چک می‌کنیم رفتن سراغش می‌ارزه یا نه
        if w_pos and not has_w:
            d_w = abs(pos[0] - w_pos[0]) + abs(pos[1] - w_pos[1])
            d_w_t = min(abs(w_pos[0] - t[0]) + abs(w_pos[1] - t[1]) for t in targets)
            return min(c_no_w, (d_w + d_w_t + mst) * 5)
            
        return c_no_w

    # صف اولویت برای الگوریتم A*
    queue = []
    counter = itertools.count()  # برای جلوگیری از ارور مقایسه Nodeها
    heapq.heappush(queue, (get_h(start_state), 0, next(counter), start_state, []))
    
    # مپ کردن استیت‌ها به کمترین هزینه دیده‌شده
    visited = {}
    
    while queue:
        f_cost, cost, _, curr_state, path = heapq.heappop(queue)
        
        # رسیدن به هدف
        if curr_state.is_goal_state():
            return path
            
        # بررسی تکراری نبودن استیت با هزینه بیشتر
        if curr_state in visited and visited[curr_state] <= cost:
            continue
        visited[curr_state] = cost
        
        # بررسی حرکت‌های بعدی
        for action, step_cost, next_state in curr_state.get_successors(toward_walls=True):
            # برخورد با دیوار مجاز نیست، مگر اینکه خود هدف باشه
            if next_state.is_collision_state() and not next_state.is_goal_state():
                continue
                
            new_cost = cost + step_cost
            
            # اگه مسیر بهتری پیدا کردیم، استیت جدید رو اضافه می‌کنیم
            if next_state not in visited or new_cost < visited[next_state]:
                h = get_h(next_state)
                heapq.heappush(queue, (new_cost + h, new_cost, next(counter), next_state, path + [action]))
                
    return []  # اگه هیچ مسیری پیدا نشد