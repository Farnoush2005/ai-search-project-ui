import heapq
import itertools

def ucs(start_state):
    queue = []
    counter = itertools.count()  # برای جلوگیری از ارور مقایسه Nodeها تو صف
    
    heapq.heappush(queue, (0, next(counter), start_state, []))
    
    # مپ کردن استیت‌ها به کمترین هزینه دیده‌شده تا الان
    visited = {start_state: 0}
    
    while queue:
        cost, _, curr_state, path = heapq.heappop(queue)
        
        # اگه رسیدیم به هدف، مسیر رو برگردون
        if curr_state.is_goal_state():
            return path
            
        # بررسی حرکت‌های مجاز بعدی
        for action, step_cost, next_state in curr_state.get_successors(toward_walls=True):
            
            # بی‌خیال مسیرهایی که به دیوار ختم میشن
            if next_state.is_collision_state():
                continue
                
            new_cost = cost + step_cost
            
            # اگه استیت جدیده یا مسیر کم‌هزینه‌تری براش پیدا کردیم، به صف اضافه‌اش می‌کنیم
            if next_state not in visited or new_cost < visited[next_state]:
                visited[next_state] = new_cost
                heapq.heappush(queue, (new_cost, next(counter), next_state, path + [action]))
                
    return []  # اگه هیچ مسیری پیدا نشد