def dls(start_state):
    # یه DLS سبک و سریع که بیشتر به درد مپ‌های easy می‌خوره
    if start_state.is_goal_state():
        return []
    
    # تابع بازگشتی برای پیمایش تا عمق مشخص
    def recursive_dls(curr_state, limit, path):
        if curr_state.is_goal_state():
            return path
            
        # رسیدیم به لیمیت، دیگه پایین‌تر نمی‌ریم
        if limit <= 0:
            return None
        
        # چک کردن حرکت‌های بعدی
        for action, step_cost, next_state in curr_state.get_successors():
            result = recursive_dls(next_state, limit - 1, path + [action])
            if result is not None:
                return result
                
        return None
    
    # عمق رو کم در نظر گرفتیم 
    depth_limit = 18
    
    result = recursive_dls(start_state, depth_limit, [])
    
    if result:
        print(f" DLS done with depth : {depth_limit}")
        return result
    else:
        print(f"DLS not done with :{depth_limit} ")
        return []

# برای استفاده تو main.py
dlsa = dls